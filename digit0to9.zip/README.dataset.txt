# digit recognition > 2025-08-04 11:31am
https://universe.roboflow.com/realtimeemployeemanagement/digit-recognition-rhpir

Provided by a Roboflow user
License: CC BY 4.0

